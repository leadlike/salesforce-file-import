
# Salesforce File Import Script

This repository contains a PowerShell script to bulk upload PDF files into Salesforce as ContentVersion records,
create related ContentDocumentLinks, and flag potential duplicates or mismatches.

## Features

- Uploads files using the Salesforce REST API
- Matches metadata from a CSV file (based on file name)
- Logs upload status and errors
- Generates a manual review queue for files requiring attention
- Avoids Data Loader limitations by using native CLI logic

## Requirements

- PowerShell 5+
- Salesforce Access Token
- Properly formatted metadata CSV file

## How to Use

1. Configure your `config.json` file with token and paths.
2. Place your `.pdf` files in the input folder.
3. Run the script:

```
.\upload.ps1
```

4. Review the generated `upload_log.txt` and `batch_manual_review.csv`.

This script is provided as-is under MIT License.
